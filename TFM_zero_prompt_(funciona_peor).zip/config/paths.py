# Configuración editable
PDF_PATH = 'data/Gramatica-Normativa-Kiche.pdf'
PROMPT_PATH = 'prompts/prompt_v3'
OUTPUT_DIR = 'output'
PAGINAS = (30, 31)  # Páginas (de la númeración pdf) a procesar (inicio, fin), ambas inclusive

# Few-shot learning (PDF completo + página específica)
FEW_SHOT_PDF_PATH = 'data/Gramatica-Normativa-Mam.pdf'
FEW_SHOT_PDF_PAGE = (205, 205)  # Rango (inicio, fin) DEBEN SER EL MISMO NÚMERO