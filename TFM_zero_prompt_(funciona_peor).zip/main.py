from config.paths import PDF_PATH, PROMPT_PATH, OUTPUT_DIR, PAGINAS, FEW_SHOT_PDF_PATH, FEW_SHOT_PDF_PAGE
from core.prompt_reader import PromptReader
from core.ai_generator import AIGenerator
from core.file_writer import FileWriter

class DocumentProcessor:
    def __init__(self):
        self.prompt_reader = PromptReader(PROMPT_PATH)
        self.ai_generator = AIGenerator()
        self.file_writer = FileWriter(OUTPUT_DIR)
    
    def run(self):
        print("\n" + "="*50)
        print("   PROCESADOR DE DOCUMENTOS CON FEW-SHOT LEARNING")
        print("="*50)
        
        print("\n⚙️ Configuración cargada:")
        print(f"   - PDF objetivo: {PDF_PATH} (páginas {PAGINAS[0]}-{PAGINAS[1]})")
        print(f"   - Ejemplo few-shot: {FEW_SHOT_PDF_PATH} (página {FEW_SHOT_PDF_PAGE[0]})")
        print(f"   - Prompt: {PROMPT_PATH}")
        print(f"   - Salida: {OUTPUT_DIR}/")
        
        print("\n📥 Cargando prompt...")
        prompt = self.prompt_reader.read()
        print(f"   - Caracteres: {len(prompt)}")
        
        print("\n🚀 Procesando con few-shot learning...")
        
        response = self.ai_generator.generate_from_pdf(PDF_PATH, prompt)
        print("\n🔍 Fragmento de respuesta:")
        print(response[:200].replace('\n', ' ') + "...")
        
        saved_path = self.file_writer.save_with_counter(response)
        print(f"\n✅ Resultado guardado en: {saved_path}")
        print(f"   - Tamaño: {len(response)} caracteres")


if __name__ == "__main__":
    processor = DocumentProcessor()
    processor.run()
    print("\n" + "="*50)
    print("   PROCESO COMPLETADO")
    print("="*50)