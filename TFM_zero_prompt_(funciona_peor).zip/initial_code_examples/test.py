import google.generativeai as genai

print("¡Paquete importado correctamente!")
print(f"Versión instalada: {genai.__version__}")