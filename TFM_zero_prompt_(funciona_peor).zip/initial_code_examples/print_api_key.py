import os
print(os.getenv("GEMINI_API_KEY"))  # Debería mostrar tu API key