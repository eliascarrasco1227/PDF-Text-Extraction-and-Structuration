from google import genai
from google.genai import types
from .pdf_processor import PDFProcessor
from config.paths import PAGINAS, FEW_SHOT_PDF_PATH, FEW_SHOT_PDF_PAGE

class AIGenerator:
    def __init__(self, model: str = 'gemini-2.5-flash'):
        self.client = genai.Client()
        self.model = model
        self.pdf_processor = PDFProcessor()
    
    def _prepare_few_shot_content(self) -> list:
        """Prepara el contenido few-shot: PDF de ejemplo + prompt estructurado"""
        # 1. Extraer página de ejemplo como PDF binario
        example_pdf_bytes = self.pdf_processor.extract_pages(
            FEW_SHOT_PDF_PATH,
            FEW_SHOT_PDF_PAGE
        )
        
        # 2. Crear prompt estructurado
        example_prompt = f"""ANÁLISIS DE EJEMPLO (Few-Shot Learning):
Por favor analiza el siguiente documento PDF (página {FEW_SHOT_PDF_PAGE[0]}) 
y genera un XML con esta estructura:

<?xml version="1.0" encoding="UTF-8"?>
<documento fuente="Gramatica-Normativa-Mam.pdf paginas="205 - 205">
<metadata>
    <title>Gramatica-Normativa-Mam</title>
    <processed_pages>204, 204</processed_pages>
</metadata>
<pagina num="204">
    <titulo> Pakb’an ipyol tuk’il ipnik’x / Predicado verbal transitivo </titulo>
        <linea> El predicado verbal transitivo está tiene dos argumentos: el su- </linea>
        <linea> jeto (agente) y objeto (paciente). El verbo transitivo (núcleo del </linea>
        <linea> predicado verbal transitivo) marca el objeto a través del juego B </linea>
        <linea> absolutivo y al sujeto a través del juego A </linea>
        <linea> ergativo. </linea>
        <interlinear_gloss>
            <paralel_phrase>
                <original>Ma txi’ tnimana tmana ex ttxu’ya.</original>
                <translation>Respetaste a tu padre y madre.</translation>
            </paralel_phrase>
            <syntactic_analysis>
                <unit>
                    <form>tnimana</form>
                    <gloss>VT</gloss>
                </unit>
                <unit>
                    <form>tmana ex ttxu’ya</form>
                    <gloss>Objeto</gloss>
                </unit>
            </syntactic_analysis>
        </interlinear_gloss>
    <titulo> Mya’ pakb’an ipyol / Predicado no verbal </titulo>
        <linea> El predicado no verbal indica estado, equivalencia, identidad, </linea>
        <linea> lugar o existencia a través de un predicado estativo cuyo nú- </linea>
        <linea> cleo puede ser un sustantivo, un adjetivo, un posicional o un </linea>
        <linea> numeral. En las oraciones con predicado no verbal interviene </linea>
        <linea> únicamente un participante que es el sujeto, para indicarlo se </linea>
        <linea> utilizan los marcadores del JB. </linea>
        <paralel_phrase>
            <original>Ttx’aqin xb’alin.</original>
            <translation>La tela está vieja.</translation>
        </paralel_phrase>
        <paralel_phrase>
            <original>Aj u’jqe’ ntzikya.</original>
            <translation>Mis hermanos mayores son escritores.</translation>
        </paralel_phrase>
        <paralel_phrase>
            <original>Mejli witz’ine twitz pop.</original>
            <translation>Mi hermano está hincado sobre el petate.</translation>
        </paralel_phrase>
  </pagina>
</documento>"""
        
        return [
            genai.types.Part(text=example_prompt), # O simplemente types.Part(text=example_prompt)
            types.Part.from_bytes(
                data=example_pdf_bytes,
                mime_type='application/pdf'
            )
        ]
    
    def generate_from_pdf(self, pdf_path: str, prompt: str) -> str:
        """
        Envía una conversación estructurada para few-shot learning.
        """
        # 1. Contenido few-shot para el turno del usuario
        few_shot_user_parts = [
            genai.types.Part(text="""ANÁLISIS DE EJEMPLO (Few-Shot Learning):
Por favor analiza el siguiente documento PDF..."""), 
            types.Part.from_bytes(
                data=self.pdf_processor.extract_pages(
                    FEW_SHOT_PDF_PATH,
                    FEW_SHOT_PDF_PAGE
                ),
                mime_type='application/pdf'
            )
        ]
        
        # 2. Contenido few-shot para el turno del modelo (la respuesta de ejemplo)
        # Aquí debes extraer o definir el XML de ejemplo como un string
        example_xml_output = """<?xml version="1.0" encoding="UTF-8"?>
<documento fuente="Gramatica-Normativa-Mam.pdf paginas="205 - 205">
<metadata>
    <title>Gramatica-Normativa-Mam</title>
    <processed_pages>204, 204</processed_pages>
</metadata>
<pagina num="204">
    <titulo> Pakb’an ipyol tuk’il ipnik’x / Predicado verbal transitivo </titulo>
    <linea> El predicado verbal transitivo está tiene dos argumentos: el su- </linea>
    ... (resto del XML de ejemplo)
</pagina>
</documento>"""

        # 3. PDF objetivo a analizar
        target_pdf_bytes = self.pdf_processor.extract_pages(pdf_path, PAGINAS)
        
        # 4. Prompt completo para la tarea real
        full_prompt = f"""INSTRUCCIONES FINALES:
{prompt}

- Mantén el formato XML del ejemplo
- Incluye metadatos del documento
- Analiza todas las páginas proporcionadas"""
        
        # Ahora, estructuramos la conversación
        conversation = [
            # Primer turno: Ejemplo de usuario (input)
            types.Content(role="user", parts=few_shot_user_parts),
            # Primer turno: Ejemplo de modelo (output)
            types.Content(role="model", parts=[types.Part(text=example_xml_output)]),
            # Segundo turno: Tarea real del usuario (input)
            types.Content(role="user", parts=[
                types.Part.from_bytes(data=target_pdf_bytes, mime_type='application/pdf'),
                genai.types.Part(text=full_prompt)
            ])
        ]
        
        # Enviar la conversación al modelo
        response = self.client.models.generate_content(
            model=self.model,
            contents=conversation
        )
        return response.text